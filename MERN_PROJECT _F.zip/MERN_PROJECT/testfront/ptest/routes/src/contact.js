import React from "react";

export default function contact() {
  return (
    <div>
      <h1>Contact JS component</h1>
    </div>
  );
}
