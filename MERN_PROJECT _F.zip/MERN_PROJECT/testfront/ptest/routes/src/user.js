import React from "react";

export default function user() {
  return (
    <div>
      <h1>User component</h1>
    </div>
  );
}
