import React from "react";

export default function Visit() {
  return (
    <div>
      <h1>Visit component</h1>
    </div>
  );
}
